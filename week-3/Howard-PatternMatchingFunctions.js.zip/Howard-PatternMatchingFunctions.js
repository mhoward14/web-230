var header = required('..header.js')

//start program

/*
    Expected output:

    Matthew Howard
    Exercise 3.2
    December 13, 2017

    // output from the if...else blocks
    Truck and Car do not match!
    Bike and Bike do match!
    Four and Three do not match!
    */

    // functions
    function match() {    
    }

    function logMismatch() {
    }

    function logMatch() {
    }

    // six (6) test varibles



    // Output from the match() function...
    console.log(match("A", "B"));
    console.log(match(2, 2));


    // Conditional "if...else" statements. Include checks for all six (6) test variables
    if (2>3) {
        console.log(false);
    } 
    else {
        console.log(true);
    }
    if (4>2) {
        console.log(true);
    }
    else {
        console.log(false);
    }
    if (21=21) {
        console.log(true);
    }
    else {
        console.log(false);
    }
    if (18>21) {
        console.log(false);
    {
    else {
        console.log(true);
    }
    if (99>98) {
        console.log(true);
    }
    else {
        console.log(false);
    }
    if (50<60) {
        console.log(true);
    }
    else {
        console.log(false);
    }

    //end program