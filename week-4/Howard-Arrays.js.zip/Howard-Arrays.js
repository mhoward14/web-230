var header = require('../header.js');

/*
 Expected output:

 Matthew Howard
 Exercise 4.2
 20 December 2017

 Apple
 Orange
 Banana
 Mango
 Pear
 */

// start program


// function
function getFruit() { 
   
    var fruit = ["Apple", "Orange", "Banana", "Mango", "Pear"];
   
    fruit.sort();
   
    console.log(getFruit());
}





// end program